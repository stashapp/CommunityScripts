STASH_SETTINGS = {
    "Scheme": "http",
    "Domain": "localhost",
    "Port": "9999",
    "ApiKey": "YOUR_API_KEY_HERE",
}
SHOW_OPTIONS = False
