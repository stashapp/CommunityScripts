Marks duplicate markers with a tag: `[Marker: Duplicate]`

Tasks -> Search for duplicate markers

It will add the tag to any markers that have an **exact** match for title, time **and** primary tag.  
It will only add to existing markers, it is up to the user to go to the tag and navigate to the scene where the duplicates will be highlighted with the tag.

(it's technically a Dupe Marker Marker)